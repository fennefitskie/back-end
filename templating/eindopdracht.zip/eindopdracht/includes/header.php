<!-- jouw HTML voor een Header komt hier... 
Gebruik hier tenminste een header afbeelding en een menu
Zorg dat je in het menu bij elk item een url parameter zet
om te bepalen welke inhoud er ingeladen moet worden in je html
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
    <li class="nav-logo">
        <img src="images/ja.jpg" alt="zo real">
    </li>
    <li><a href="index.php?page=attack_on_titan">Attack on Titan</a></li>
    <li><a href="index.php?page=eren">Eren</a></li>
    <li><a href="index.php?page=hange">Hange</a></li>
    <li><a href="index.php?page=armin">Armin</a></li>
</ul>

</body>
</html>