<div class="content">
    <h1>Eren Yeager</h1>
    <p>
        Eren Yeager is de complexe en tragische hoofdpersoon van Attack on Titan. In het begin van de serie is hij een vurige en impulsieve jongen die zweert om alle Titans uit te roeien nadat hij zijn moeder voor zijn ogen verliest. Zijn intense haat en verlangen naar vrijheid vormen de drijvende kracht achter zijn keuzes. Samen met zijn vrienden Mikasa en Armin sluit hij zich aan bij het leger, vastbesloten om de mensheid te redden.

        Naarmate het verhaal vordert, verandert Eren drastisch. Hij ontdekt dat hij zelf de kracht bezit om in een Titan te veranderen, en dat de ware vijand niet de Titans buiten de muren zijn, maar het corrupte systeem waarin hij is opgegroeid. Eren wordt steeds radicaler in zijn denkbeelden en acties, en zijn strijd voor vrijheid verandert in een wereldwijde oorlog.

        Wat Eren uniek maakt, is dat hij zowel held als antagonist is. Zijn keuzes brengen hem steeds verder van zijn vrienden af, maar in zijn ogen doet hij alles voor de vrijheid van zijn volk. Zijn ontwikkeling roept vragen op over moraliteit, opoffering en of vrijheid ten koste van alles gerechtvaardigd is.
    </p>
    <img src="images/eren.jpg" alt="Eren Yeager">
</div>