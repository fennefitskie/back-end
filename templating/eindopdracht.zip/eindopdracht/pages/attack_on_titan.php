<div class="content">
    <h1>Attack on titan</h1>
    <p>
        Attack on Titan (Shingeki no Kyojin) is een Japanse manga- en animeserie, geschreven door Hajime Isayama, die wereldwijd bekendstaat om zijn meeslepende verhaal en diepgaande thema’s. De serie speelt zich af in een wereld waarin de mensheid schuilt achter enorme muren om zich te beschermen tegen reusachtige wezens genaamd Titans, die mensen zonder reden opeten. Wat begint als een klassiek overlevingsverhaal verandert al snel in een gelaagd en politiek drama.

        Het verhaal volgt Eren Yeager, een jonge jongen die zijn moeder verliest aan een Titan en zweert de wereld te bevrijden van deze monsters. Samen met zijn vrienden Mikasa Ackerman en Armin Arlert sluit hij zich aan bij het leger. Naarmate ze hogerop komen, ontdekken ze dat de ware bedreiging niet alleen van buiten de muren komt, maar ook van binnen. De serie onthult langzaamaan schokkende waarheden over de oorsprong van de Titans, de verborgen geschiedenis van de mensheid, en de ware betekenis van vrijheid.

        Attack on Titan onderzoekt zware thema’s zoals onderdrukking, genocide, oorlog en morele grijsgebieden. Het dwingt de kijker om na te denken over goed en kwaad, en de prijs die betaald moet worden voor vrede.
    </p>
    <img src="images/aot.jpg" alt="Attack on titan">
</div>