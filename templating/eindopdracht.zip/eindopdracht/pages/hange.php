<div class="content">
    <h1>Hange Zoë</h1>
    <p>
        Hange Zoë is een briljante wetenschapper en een excentriek lid van het Verkenningslegioen. Hange staat bekend om hun enorme nieuwsgierigheid naar Titans. Waar anderen Titans enkel als monsters zien, ziet Hange ze als mysteries die ontrafeld moeten worden. Hun wetenschappelijke benadering, gecombineerd met een bijna obsessieve fascinatie, levert vaak komische momenten op, maar ook belangrijke doorbraken in het begrijpen van de Titans.

        Na de dood van Erwin Smith wordt Hange de nieuwe commandant van het Verkenningslegioen. In deze rol laat Hange zien dat ze niet alleen intelligent zijn, maar ook moedig, verantwoordelijk en toegewijd aan het welzijn van hun kameraden. Ze worstelen met de zware beslissingen die leiderschap met zich meebrengt, vooral wanneer het gaat om opofferingen in de strijd om vrijheid.

        Hange is non-binair gecodeerd in de originele manga (Isayama gaf bewust geen geslacht aan het personage), wat hen uniek maakt binnen de cast. Hun tragische, heldhaftige dood symboliseert hun toewijding aan de missie en de hoop op een betere wereld.

        Hange combineert humor, intellect en opoffering op een manier die hen tot een van de meest gedenkwaardige personages van de serie maakt.
    </p>
    <img src="images/hange.jpg" alt="Hange Zoë">
</div>