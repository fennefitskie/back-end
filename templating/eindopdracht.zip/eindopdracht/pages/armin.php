<div class="content">
    <h1>Armin Arlert</h1>
    <p>
        Armin Arlert is een van de slimste en meest gevoelige personages in Attack on Titan. Hij groeit op als de beste vriend van Eren Yeager en Mikasa Ackerman. In tegenstelling tot hen blinkt Armin niet uit in fysieke kracht, maar wel in strategie, logisch denken en moreel inzicht. Wat hij mist aan kracht, maakt hij goed met zijn briljante geest en overtuigingskracht.

        Armin gelooft sterk in de waarde van kennis, ontdekkingen en vrede. Zijn droom is altijd geweest om de wereld buiten de muren te zien — de zee, de woestijnen, de bergen. Die droom geeft hem hoop in een wrede wereld. Hij is vaak degene die het geweten van de groep vertegenwoordigt en nadenkt over de lange termijn gevolgen van hun keuzes.

        Na de dood van Erwin Smith wordt Armin gekozen om de Colossal Titan te erven — een enorme verantwoordelijkheid. Die keuze symboliseert de hoop op een toekomst waarin intelligentie en mededogen zwaarder wegen dan brute kracht.

        Armin worstelt regelmatig met twijfel, maar toont steeds meer leiderschap. Zijn ontwikkeling van onzeker jongetje tot strategisch leider maakt hem tot een van de meest diepgaande en inspirerende personages van de serie.
    </p>
    <img src="images/armin.jpg" alt="Armin Arlert">
</div>